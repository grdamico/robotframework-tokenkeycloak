# Robotframework-tokenkeycloak
A Robotframework library to manage the Keycloak Token 
[Documentation](http://graziadamico.altervista.org/robotframework/Tokenkeycloak.html)