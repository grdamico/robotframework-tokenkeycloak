class ErrorToken(Exception):
    pass